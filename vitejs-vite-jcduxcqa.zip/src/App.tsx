import React, { useEffect, useMemo, useRef, useState } from "react";

/* =========================================
   Utils
   ========================================= */
function uid() {
  try {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
      return (crypto as any).randomUUID();
    }
  } catch {}
  return "id-" + Math.random().toString(36).slice(2);
}

function cls(...xs: Array<string | false | null | undefined>) {
  return xs.filter(Boolean).join(" ");
}

function useLocalStorage<T>(key: string, def: T) {
  const [v, setV] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : def;
    } catch {
      return def;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(v));
    } catch {}
  }, [key, v]);
  return [v, setV] as const;
}

function downloadFile(filename: string, content: string, mime = "text/plain;charset=utf-8") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const fileToDataURL = (file: File) =>
  new Promise<string>((res) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.readAsDataURL(file);
  });

/* =========================================
   Types
   ========================================= */
type Theme = { primary: string; secondary: string; surface: string; text: string };

type Team = { id: string; name: string; color: string; logoDataUrl?: string };

type Profile = {
  id: string;
  name: string;
  avatarDataUrl?: string;
  teamId?: string;
  stats?: { games: number; legs: number; sets?: number; darts: number };
  // tu pourras étendre plus tard
};

type Player = {
  id: string;
  name: string;
  profileId?: string;
  avatarDataUrl?: string;
  teamId?: string;
  x01Score: number;
  legs: number;
  sets: number;
  dartsUsed: number;
  lastScore: number;
  points: number;
  lives: number;
  atcTarget: number;
    // Killer
    killerTarget?: number;   // 1..20
    isKiller?: boolean;      // a validé sa double
    // Shanghai
    shanghaiRound?: number;  // 1..20 (compteur local par joueur, ou global)  
};

type MatchRules = { startingScore: number; doubleOut: boolean; legsToWinSet: number; setsToWinMatch: number };

type Mode =
  | "X01"
  | "Cricket"
  | "Tour de l'horloge"
  | "Battle Royale"
  | "Killer"
  | "Shanghai"
  | "Bob's 27"
  | "Baseball"
  | "Tic-Tac-Toe"
  | "Mario Dart"
  | "Knockout"
  | "Halve-It"
  | "Scram"
  | "Shooter"
  | "Prisonner"
  | "Finish 170"
  | "Finish 121"
  | "Training";

  type Route = 'home' | 'games' | 'lobby' | 'game' | 'gamestats' | 'profiles' | 'stats' | 'teams' | 'settings';

/* ---------- Events / Games (journal & historique) ---------- */
type Dart = { mult: 1 | 2 | 3; val: number }; // 25 = bull (DB si mult===2)

type GameEvent = {
  id: string;
  ts: number;
  profileId: string;
  mode: Mode;
  darts: Dart[];
  total: number;
  tags?: string[];
  meta?: { gameId?: string; leg?: number; x01Before?: number; x01After?: number };
};

type GameRecord = {
  id: string;
  mode: Mode;
  startedAt: number;
  finishedAt?: number;
  players: { profileId: string; name: string }[];
  winnerId?: string;
  notes?: string;
};

/* =========================================
   Defaults
   ========================================= */
const DEFAULT_THEME: Theme = {
  primary: "#f59e0b",
  secondary: "#0ea5e9",
  surface: "#0b0b0d",
  text: "#f5f5f5",
};
const DEFAULT_RULES: MatchRules = { startingScore: 501, doubleOut: true, legsToWinSet: 3, setsToWinMatch: 2 };

/* =========================================
   Global mini styles helper
   ========================================= */
function GlobalStyles() {
  return (
    <style>{`
      :root{
        --c-primary: ${DEFAULT_THEME.primary};
        --c-text: ${DEFAULT_THEME.text};
      }
      *{ box-sizing: border-box; }
      html, body, #root { height: 100%; }
      button { font: inherit; }
      @media (max-width: 768px){
        .hide-sm { display: none !important; }
        .show-sm { display: initial !important; }
      }
      @media (min-width: 769px){
        .hide-lg { display: none !important; }
      }
    `}</style>
  );
}

// ============================
// 📘 RÈGLES OFFICIELLES PAR JEU
// ============================

const GAME_RULES: Record<string, string> = {
  X01: `
Objectif : Atteindre exactement zéro en partant de 501 (ou 301).
Chaque fléchette soustrait son score du total. 
La dernière fléchette doit être un double (ou le Bull double) pour finir la manche.
`,
  CRICKET: `
Objectif : Fermer les numéros 15 à 20 et le Bull avant l’adversaire.
Un simple compte pour 1, un double pour 2 et un triple pour 3. 
Une fois fermé, tu marques des points si ton adversaire ne l’a pas encore fermé.
`,
  TOUR_DE_LHORLOGE: `
Objectif : Toucher tous les numéros dans l’ordre de 1 à 20, puis le Bull.
Un seul tir par chiffre. Le premier joueur à finir gagne la partie.
`,
  BATTLE_ROYALE: `
Objectif : Survivre le plus longtemps possible. 
Tous les joueurs commencent avec 3 vies. 
À chaque tour, le joueur avec le plus petit score perd une vie. 
Quand il ne reste qu’un joueur, il remporte la manche !
`,
  KILLER: `
Chaque joueur reçoit un numéro aléatoire entre 1 et 20. 
Il doit d’abord toucher le double de ce numéro pour devenir un "Killer". 
Une fois Killer, chaque double touché du numéro d’un adversaire lui enlève une vie.
Dernier joueur en vie gagne la partie.
`,
  SHANGHAI: `
Chaque manche cible un numéro (1 à 20). 
Simple = 1 point, double = 2, triple = 3. 
Faire simple + double + triple du même chiffre dans la manche = “Shanghai” → victoire immédiate !
`,
  BOBS_27: `
Chaque joueur commence avec 27 points. 
Chaque manche cible un double spécifique. 
Si tu touches, tu gagnes le double de la valeur (ex: D10 = +20). 
Si tu rates les 3 fléchettes, tu perds la valeur du double. 
Le score tombe à zéro → éliminé.
`,
  BASEBALL: `
Jeu en 9 manches. Chaque manche cible un numéro (1 à 9). 
Simple = 1 point, double = 2, triple = 3. 
Le joueur avec le plus haut total à la fin gagne.
`,
  TIC_TAC_TOE: `
Deux joueurs s’affrontent sur une grille de 9 cases (3x3). 
Chaque case correspond à un numéro à fermer. 
Ferme une ligne (horizontal, vertical, diagonal) pour gagner.
`,
  MARIO_DART: `
Variante fun : chaque volée active un bonus ou un malus aléatoire. 
Exemples : “+50 points”, “inversion du score”, “lancer annulé”.
`,
  KNOCKOUT: `
Chaque joueur joue après l’autre. 
Si ton score est inférieur à celui du joueur précédent, tu perds une vie. 
À zéro vie → éliminé. Dernier joueur restant gagne.
`,
  HALVE_IT: `
Chaque tour a un objectif (ex : T20, D16, Bull). 
Rater l’objectif divise ton score total par deux. 
Le joueur avec le plus haut score à la fin gagne.
`,
  SCRAM: `
Deux rôles : un marqueur et un bloqueur. 
Le bloqueur tente de fermer les chiffres 1 à 20 et Bull. 
Une fois fermé, le marqueur ne peut plus marquer dessus. 
Les rôles s’inversent à mi-partie.
`,
  SHOOTER: `
Objectif : marquer le plus haut score possible sur un nombre de tours fixe. 
Tous les chiffres et multiplications comptent.
`,
  PRISONNER: `
Rater la cible Bull te met en prison. 
Pour sortir, tu dois toucher le Double 20. 
Tu ne peux pas marquer tant que tu es prisonnier !
`,
  FINISH_121: `
Commence à 121 points. 
Tu as 9 fléchettes maximum pour finir exactement à zéro. 
Double obligatoire pour finir. Si tu rates → échec.
`,
  FINISH_170: `
Commence à 170 points. 
Objectif : checkout parfait en 3 fléchettes (T20 + T20 + Bull). 
Moins de 3 fléchettes → manche perdue.
`,
};
/* Associe les valeurs du type Mode aux clés de GAME_RULES */
const MODE_TO_RULE_KEY: Record<string, string> = {
  "X01": "X01",
  "Cricket": "CRICKET",
  "Tour de l'horloge": "TOUR_DE_LHORLOGE",
  "Battle Royale": "BATTLE_ROYALE",
  "Killer": "KILLER",
  "Shanghai": "SHANGHAI",
  "Bob's 27": "BOBS_27",
  "Baseball": "BASEBALL",
  "Tic-Tac-Toe": "TIC_TAC_TOE",
  "Mario Dart": "MARIO_DART",
  "Knockout": "KNOCKOUT",
  "Halve-It": "HALVE_IT",
  "Scram": "SCRAM",
  "Shooter": "SHOOTER",
  "Prisonner": "PRISONNER",
  "Finish 121": "FINISH_121",
  "Finish 170": "FINISH_170",
  "Training": "TRAINING", // si tu as ajouté TRAINING dans GAME_RULES
};
// =========================================
// GameStatsPage (aperçu des stats de partie)
// =========================================
function GameStatsPage({
  players,
  onBack,
}: {
  players: Player[];
  onBack: () => void;
}) {
  return (
    <section style={{ display: "grid", gap: 12 }}>
      <button
        onClick={onBack}
        style={{
          background: "#111",
          color: "#fff",
          border: "1px solid #333",
          padding: "8px 12px",
          borderRadius: 12,
        }}
      >
        ← Retour
      </button>

      <h3 style={{ fontWeight: 800, fontSize: 18 }}>📊 Stats de la partie</h3>

      <div style={{ display: "grid", gap: 8 }}>
        {players.map((p) => (
          <div
            key={p.id}
            style={{
              border: "1px solid #2a2a2a",
              borderRadius: 12,
              padding: 10,
              background: "#121212",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Avatar name={p.name} src={p.avatarDataUrl} size={40} />
              <b>{p.name}</b>
            </span>
            <span style={{ fontFamily: "monospace", fontSize: 13 }}>
              Darts <b>{p.dartsUsed}</b> • Dernière volée <b>{p.lastScore}</b> • Moy 3D{" "}
              <b>
                {(((501 - p.x01Score) / Math.max(1, p.dartsUsed)) * 3).toFixed(2)}
              </b>
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}

/* =========================================
   App
   ========================================= */
export default function App() {
  const [route, setRoute] = useLocalStorage<Route>("dc.route", "home");
  const [arcade, setArcade] = useLocalStorage<boolean>("dc.arcade", false);

  // Data
  const [teams, setTeams] = useLocalStorage<Team[]>("dc.teams", []);
  const [profiles, setProfiles] = useLocalStorage<Profile[]>("dc.profiles", [
    { id: uid(), name: "Profil 1", stats: { games: 0, legs: 0, sets: 0, darts: 0 } },
  ]);

  const [rules, setRules] = useLocalStorage<MatchRules>("dc.rules", DEFAULT_RULES);
  const [mode, setMode] = useLocalStorage<Mode>("dc.mode", "X01");

  const [players, setPlayers] = useState<Player[]>([]);
  const [activeId, setActiveId] = useState<string>("");

  const [events, setEvents] = useLocalStorage<GameEvent[]>("dc.events", []);
  const [games, setGames] = useLocalStorage<GameRecord[]>("dc.games", []);
  const [currentGameId, setCurrentGameId] = useLocalStorage<string | null>("dc.currentGameId", null);

  // PWA install prompt
  const deferredPrompt = useRef<any>(null);
  useEffect(() => {
    const onBip = (e: any) => {
      e.preventDefault();
      deferredPrompt.current = e;
    };
    window.addEventListener("beforeinstallprompt", onBip);
    return () => window.removeEventListener("beforeinstallprompt", onBip);
  }, []);

  // Theme apply
  useEffect(() => {
    const r = document.documentElement;
    r.style.setProperty("--c-primary", DEFAULT_THEME.primary);
    r.style.setProperty("--c-text", DEFAULT_THEME.text);
  }, []);

  // Start lobby from GamesHub
  function startLobby(m: Mode) {
    setMode(m);
    setRoute("lobby");
  }

  // Launch game from Lobby
  function launchGame(selected: Player[], customRules?: MatchRules) {
    // crée une partie
    const gameId = uid();
    setGames((gs) => [
      ...gs,
      {
        id: gameId,
        mode,
        startedAt: Date.now(),
        players: selected.map((p) => ({ profileId: p.profileId || p.id, name: p.name })),
      },
    ]);
    setCurrentGameId(gameId);

    // instancie les joueurs pour la manche
    const r = customRules || rules;
    const js = selected.map((p) => ({
      id: uid(),
      name: p.name,
      profileId: p.profileId || undefined,
      avatarDataUrl: p.avatarDataUrl,
      teamId: p.teamId,
      x01Score: r.startingScore,
      legs: 0,
      sets: 0,
      dartsUsed: 0,
      lastScore: 0,
      points: 0,
      lives: 3,
      atcTarget: 1,
      // ↓↓↓ init Killer / Shanghai
      killerTarget: undefined, // sera attribué au premier rendu GamePage
      isKiller: false,
      shanghaiRound: 1,
    }));    
    setPlayers(js);
    setActiveId(js[0]?.id || "");
    if (customRules) setRules(customRules);
    setRoute("game");
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: arcade
          ? "radial-gradient(1200px 600px at 30% -10%, #0d0f2a, #050510 40%, #000), linear-gradient(135deg, rgba(0,255,204,.08), rgba(255,0,128,.05))"
          : "radial-gradient(1200px 600px at 30% -10%, #141517, #0a0a0a 40%, #000)",
        color: "#fff",
        paddingBottom: 80,
        fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
      }}
    >
      <GlobalStyles />

      <TopGlassNav route={route} setRoute={setRoute} />

      <main style={{ maxWidth: 1000, margin: "0 auto", padding: 16 }}>
        {route === "home" && (
          <Home onGoGames={() => setRoute("games")} onGoProfiles={() => setRoute("profiles")} />
        )}

        {route === "games" && <GamesHub current={mode} onPick={startLobby} />}

        {route === "profiles" && (
          <ProfilesPage profiles={profiles} setProfiles={setProfiles} teams={teams} setTeams={setTeams} events={events} />
        )}

        {route === "allgames" && (
          <AllGamesPage games={games} events={events} profiles={profiles} onOpen={(id) => console.log("open", id)} />
        )}

        {route === "lobby" && (
          <LobbyPage
            mode={mode}
            teams={teams}
            profiles={profiles}
            rules={rules}
            setRules={setRules}
            onStart={launchGame}
            onBack={() => setRoute("games")}
          />
        )}

        {route === "game" && (
          <GamePage
            mode={mode}
            rules={rules}
            players={players}
            setPlayers={setPlayers}
            activeId={activeId}
            setActiveId={setActiveId}
            onEnd={() => setRoute("home")}
            profiles={profiles}
            setProfiles={setProfiles}
            events={events}
            setEvents={setEvents}
            currentGameId={currentGameId}
            setGames={setGames}
            setCurrentGameId={setCurrentGameId}
          />
        )}
        {route === "gamestats" && (
  <GameStatsPage
    players={players}
    onBack={() => setRoute("game")}
  />
)}

        {route === "stats" && <StatsPage profiles={profiles} />}

        {route === "teams" && <TeamsPage teams={teams} setTeams={setTeams} />}

        {route === "settings" && (
          <SettingsPage rules={rules} setRules={setRules} arcade={arcade} setArcade={setArcade} />
        )}
      </main>

      <BottomNav route={route} setRoute={setRoute} />
    </div>
  );
}

/* =========================================
   Header (bouton installer PWA)
   ========================================= */
function Header({ onInstall }: { onInstall: () => void }) {
  return (
    <header className="hide-sm" style={{ maxWidth: 1000, margin: "0 auto", padding: "8px 16px 0" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, justifyContent: "space-between" }}>
        <div>
          <div style={{ fontWeight: 800, fontSize: 20 }}>Darts Counter</div>
          <div style={{ opacity: 0.7, fontSize: 12 }}>UI “verre dépoli” • PWA ready</div>
        </div>
        <button
          onClick={onInstall}
          style={{
            background: "var(--c-primary)",
            color: "#111",
            padding: "8px 12px",
            border: "none",
            borderRadius: 10,
            fontWeight: 800,
          }}
        >
          Installer
        </button>
      </div>
    </header>
  );
}

/* =========================================
   Home (placeholder)
   ========================================= */
function Home({ onGoGames, onGoProfiles }: { onGoGames: () => void; onGoProfiles: () => void }) {
  return (
    <section style={{ display: "grid", gap: 12 }}>
      <Header
        onInstall={() => {
          alert("Ajoute manifest.json + service-worker.js pour l’installation.");
        }}
      />
      <div
        style={{
          padding: 16,
          borderRadius: 16,
          border: "1px solid rgba(255,255,255,.08)",
          background: "linear-gradient(180deg, rgba(20,20,24,.45), rgba(10,10,12,.55))",
        }}
      >
        <div style={{ fontWeight: 700, marginBottom: 8 }}>Bienvenue 🎯</div>
        <div style={{ opacity: 0.8, marginBottom: 12 }}>
          Lance une partie, gère tes profils & équipes, et explore les stats.
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <GlassButton onClick={onGoGames} leftIcon="dart">
            Lancer une partie
          </GlassButton>
          <GlassButton onClick={onGoProfiles} leftIcon="user">
            Profils
          </GlassButton>
        </div>
      </div>
    </section>
  );
}

/* =========================================
   GamesHub (placeholder)
   ========================================= */
/* ===================== GamesHub (menu des jeux) ===================== */
function GamesHub({
  current,
  onPick,
}: {
  current: string;
  onPick: (mode: string) => void;
}) {
  // Liste visible
  const games: Array<{ key: string; label: string; desc: string }> = [
    { key: "X01", label: "X01", desc: "301/501/701/1001 — double-out" },
    { key: "Cricket", label: "Cricket", desc: "15–20 + Bull, fermetures & points" },
    { key: "Tour de l'horloge", label: "Tour de l'horloge", desc: "1→20 puis Bull, en ordre" },
    { key: "Battle Royale", label: "Battle Royale", desc: "Vies, manches, éliminations" },
    { key: "Killer", label: "Killer", desc: "Double de ton numéro → deviens Killer" },
    { key: "Shanghai", label: "Shanghai", desc: "Cible du tour, S/D/T — Shanghai = win" },
    { key: "Bob's 27", label: "Bob’s 27", desc: "Doubles successifs, +/− points" },
    { key: "Baseball", label: "Baseball", desc: "9 manches, S=1 D=2 T=3" },
    { key: "Tic-Tac-Toe", label: "Tic-Tac-Toe", desc: "Grille 3×3, fermer une ligne" },
    { key: "Mario Dart", label: "Mario Dart", desc: "Bonus/malus fun à chaque volée" },
    { key: "Knockout", label: "Knockout", desc: "Score < joueur précédent → vie −1" },
    { key: "Halve-It", label: "Halve-It", desc: "Rater l’objectif = score ÷ 2" },
    { key: "Scram", label: "Scram", desc: "Bloquer vs marquer, rôles alternés" },
    { key: "Shooter", label: "Shooter", desc: "Maximiser le score sur tours fixes" },
    { key: "Prisonner", label: "Prisonner", desc: "Prison si échec, D20 pour sortir" },
    { key: "Finish 121", label: "Finish 121", desc: "Finir 121 en 9 darts (double-out)" },
    { key: "Finish 170", label: "Finish 170", desc: "Checkout parfait T20+T20+Bull" },
    { key: "Training", label: "TRAINING", desc: "Simple · Double · Score" },
  ];

  return (
    <section style={{ display: "grid", gap: 12 }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          justifyContent: "space-between",
        }}
      >
        <div>
          <div style={{ fontWeight: 800, fontSize: 18 }}>Tous les jeux</div>
          <div style={{ opacity: 0.7, fontSize: 12 }}>
            Choisis un mode — clique sur <b>i</b> pour voir les règles
          </div>
        </div>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
          gap: 10,
        }}
      >
        {games.map((g) => (
          <div
            key={g.key}
            style={{
              borderRadius: 16,
              border: "1px solid #2a2a2a",
              background:
                "linear-gradient(180deg, rgba(20,20,24,.55), rgba(10,10,12,.85))",
              padding: 14,
              display: "grid",
              gap: 8,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ fontWeight: 800 }}>{g.label}</div>
              <div style={{ marginLeft: "auto" }}>
                <InfoButton mode={g.key} />
              </div>
            </div>
            <div style={{ opacity: 0.7, fontSize: 12 }}>{g.desc}</div>
            <button
              onClick={() => onPick(g.key)}
              style={{
                borderRadius: 12,
                border: "1px solid rgba(255,255,255,.08)",
                background:
                  current === g.key
                    ? "linear-gradient(180deg, #fbbf24, #f59e0b)"
                    : "linear-gradient(180deg, rgba(20,20,24,.45), rgba(10,10,12,.55))",
                color: current === g.key ? "#111" : "#eee",
                padding: "8px 12px",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              {current === g.key ? "Sélectionné" : "Choisir"}
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}

/* =========================================
   ProfilesPage (minimal, compile)
   ========================================= */
function ProfilesPage({
  profiles,
  setProfiles,
  teams,
  setTeams,
  events,
}: {
  profiles: Profile[];
  setProfiles: (u: any) => void;
  teams: Team[];
  setTeams: (u: any) => void;
  events: GameEvent[];
}) {
  const [selectedId, setSelectedId] = useState<string>(() => profiles[0]?.id || "");
  const selected = useMemo(() => profiles.find((p) => p.id === selectedId), [profiles, selectedId]);

  const [newName, setNewName] = useState("");

  async function uploadAvatar(f?: File) {
    if (!selected || !f) return;
    const url = await fileToDataURL(f);
    setProfiles((arr: Profile[]) => arr.map((p) => (p.id === selected.id ? { ...p, avatarDataUrl: url } : p)));
  }

  function addProfile() {
    const name = newName.trim() || `Joueur ${profiles.length + 1}`;
    const p: Profile = { id: uid(), name, stats: { games: 0, legs: 0, darts: 0, sets: 0 } };
    setProfiles((arr: Profile[]) => [...arr, p]);
    setNewName("");
    setSelectedId(p.id);
  }

  return (
    <section style={{ display: "grid", gap: 12 }}>
      <div className="hide-sm">
        <SectionTabs
          tabs={[
            { key: "list", label: "Profils", icon: "user" },
            { key: "stats", label: "Stats (bêta)", icon: "chart" },
          ]}
          value={"list"}
          onChange={() => {}}
        />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", gap: 12 }}>
        <div
          style={{
            border: "1px solid rgba(255,255,255,.08)",
            background: "linear-gradient(180deg, rgba(20,20,24,.45), rgba(10,10,12,.55))",
            borderRadius: 12,
            padding: 10,
          }}
        >
          <div style={{ display: "flex", gap: 8, marginBottom: 8, alignItems: "center" }}>
  <input
    value={newName}
    onChange={(e) => setNewName(e.target.value)}
    placeholder="Nom du profil"
    style={{
      flex: 1,
      padding: "8px 10px",
      borderRadius: 10,
      border: "1px solid #333",
      background: "#0f0f10",
      color: "#eee",
      fontSize: 14,
    }}
  />

  <button
    onClick={addProfile}
    aria-label="Ajouter un joueur"
    title="Ajouter un joueur"
    onMouseEnter={(e) => (e.currentTarget.style.filter = "brightness(1.1)")}
    onMouseLeave={(e) => (e.currentTarget.style.filter = "none")}
    style={{
      width: 32,
      height: 32,
      minWidth: 32,
      minHeight: 32,
      borderRadius: 9999,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--c-primary)",
      color: "#111",
      border: "1px solid rgba(0,0,0,.25)",
      boxShadow: "0 6px 14px rgba(0,0,0,.35)",
      lineHeight: 1,
      padding: 0,
      cursor: "pointer",
      fontWeight: 800,
    }}
  >
    <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
      {/* Silhouette de joueur */}
      <svg
        width="14"
        height="14"
        viewBox="0 0 24 24"
        fill="currentColor"
        aria-hidden="true"
        style={{ opacity: 0.9 }}
      >
        <path d="M12 12c2.761 0 5-2.686 5-6s-2.239-6-5-6-5 2.686-5 6 2.239 6 5 6zm0 2c-4.418 0-8 2.239-8 5v3h16v-3c0-2.761-3.582-5-8-5z"/>
      </svg>
      <span>+</span>
    </span>
  </button>
          </div>
          <div style={{ display: "grid", gap: 6, maxHeight: 380, overflow: "auto", paddingRight: 4 }}>
            {profiles.map((p) => (
              <button
                key={p.id}
                onClick={() => setSelectedId(p.id)}
                style={{
                  textAlign: "left",
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  padding: 8,
                  borderRadius: 10,
                  border: "1px solid rgba(255,255,255,.08)",
                  background:
                    selectedId === p.id
                      ? "radial-gradient(120px 60px at 50% -20%, rgba(245,158,11,.35), rgba(245,158,11,.08))"
                      : "#0e0e10",
                  color: selectedId === p.id ? "var(--c-primary)" : "#e7e7e7",
                  fontWeight: selectedId === p.id ? 800 : 600,
                }}
              >
                <Avatar name={p.name} src={p.avatarDataUrl} />
                <div>
                  <div>{p.name}</div>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>
                    {p.stats?.games ?? 0} parties · {p.stats?.legs ?? 0} legs · {p.stats?.darts ?? 0} darts
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div
          style={{
            border: "1px solid rgba(255,255,255,.08)",
            background: "linear-gradient(180deg, rgba(20,20,24,.45), rgba(10,10,12,.55))",
            borderRadius: 12,
            padding: 12,
          }}
        >
          {!selected ? (
            <div style={{ opacity: 0.7 }}>Sélectionne un profil.</div>
          ) : (
            <>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
                <Avatar name={selected.name} src={selected.avatarDataUrl} size={100} />
                <input
                  value={selected.name}
                  onChange={(e) =>
                    setProfiles((arr: Profile[]) =>
                      arr.map((p) => (p.id === selected.id ? { ...p, name: e.target.value } : p))
                    )
                  }
                  style={{
                    flex: 1,
                    padding: "8px 10px",
                    borderRadius: 10,
                    border: "1px solid #333",
                    background: "#0f0f10",
                    color: "#eee",
                  }}
                />
                <label
                  style={{
                    padding: "8px 10px",
                    borderRadius: 10,
                    border: "1px solid rgba(255,255,255,.08)",
                    background: "#111",
                    cursor: "pointer",
                  }}
                >
                  Changer avatar
                  <input
                    type="file"
                    accept="image/*"
                    className="hide-lg"
                    onChange={(e) => uploadAvatar(e.target.files?.[0])}
                  />
                </label>
              </div>

              <div style={{ fontWeight: 700, marginBottom: 6 }}>Aperçu des stats (volées)</div>
              <div style={{ fontSize: 14, opacity: 0.85 }}>
                Volées enregistrées pour ce profil :{" "}
                {events.filter((ev) => ev.profileId === selected.id).length}
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
}

/* =========================================
   LobbyPage (minimal)
   ========================================= */
function LobbyPage({
  mode,
  teams,
  profiles,
  rules,
  setRules,
  onStart,
  onBack,
}: {
  mode: Mode;
  teams: Team[];
  profiles: Profile[];
  rules: MatchRules;
  setRules: (r: MatchRules) => void;
  onStart: (players: Player[], customRules?: MatchRules) => void;
  onBack: () => void;
}) {
  const [selected, setSelected] = useState<string[]>([]);
  const [localRules, setLocalRules] = useState<MatchRules>(rules);

  function toggle(id: string) {
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  }

  function start() {
    const chosen = profiles
      .filter((p) => selected.includes(p.id))
      .map<Player>((p) => ({
        id: uid(),
        name: p.name,
        profileId: p.id,
        avatarDataUrl: p.avatarDataUrl,
        teamId: p.teamId,
        x01Score: localRules.startingScore,
        legs: 0,
        sets: 0,
        dartsUsed: 0,
        lastScore: 0,
        points: 0,
        lives: 3,
        atcTarget: 1,
      }));
    if (chosen.length === 0) {
      alert("Sélectionne au moins 1 joueur.");
      return;
    }
    onStart(chosen, localRules);
  }

  return (
    <section style={{ display: "grid", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <GlassButton onClick={onBack} leftIcon="folder">
          Retour
        </GlassButton>
        <div style={{ opacity: 0.8 }}>Mode : <b>{mode}</b></div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <div
          style={{
            border: "1px solid rgba(255,255,255,.08)",
            background: "linear-gradient(180deg, rgba(20,20,24,.45), rgba(10,10,12,.55))",
            borderRadius: 12,
            padding: 12,
          }}
        >
          <div style={{ fontWeight: 700, marginBottom: 8 }}>Joueurs</div>
          <div style={{ display: "grid", gap: 6, maxHeight: 360, overflow: "auto", paddingRight: 4 }}>
            {profiles.map((p) => {
              const is = selected.includes(p.id);
              return (
                <button
                  key={p.id}
                  onClick={() => toggle(p.id)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    textAlign: "left",
                    padding: 8,
                    borderRadius: 10,
                    border: "1px solid rgba(255,255,255,.08)",
                    background: is
                      ? "radial-gradient(120px 60px at 50% -20%, rgba(245,158,11,.35), rgba(245,158,11,.08))"
                      : "#0e0e10",
                    color: is ? "var(--c-primary)" : "#e7e7e7",
                    fontWeight: is ? 800 : 600,
                  }}
                >
                  <Avatar name={p.name} src={p.avatarDataUrl} />
                  <div>
                    <div>{p.name}</div>
                    <div style={{ fontSize: 12, opacity: 0.7 }}>
                      {teams.find((t) => t.id === p.teamId)?.name || "(Aucune équipe)"}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div
          style={{
            border: "1px solid rgba(255,255,255,.08)",
            background: "linear-gradient(180deg, rgba(20,20,24,.45), rgba(10,10,12,.55))",
            borderRadius: 12,
            padding: 12,
          }}
        >
          <div style={{ fontWeight: 700, marginBottom: 8 }}>Paramètres</div>
          {mode === "X01" && (
            <>
              <div style={{ marginBottom: 6, opacity: 0.8 }}>Score de départ</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 8 }}>
                {[301, 501, 701, 1001].map((s) => (
                  <GlassButton
                    key={s}
                    onClick={() => setLocalRules({ ...localRules, startingScore: s })}
                    active={localRules.startingScore === s}
                  >
                    {s}
                  </GlassButton>
                ))}
              </div>
              <label style={{ display: "flex", alignItems: "center", gap: 8, opacity: 0.9 }}>
                <input
                  type="checkbox"
                  checked={localRules.doubleOut}
                  onChange={(e) => setLocalRules({ ...localRules, doubleOut: e.target.checked })}
                />
                Sortie en double
              </label>
            </>
          )}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 10 }}>
            <div>
              <div style={{ marginBottom: 4, opacity: 0.8 }}>Legs / set</div>
              <input
                type="number"
                min={1}
                value={localRules.legsToWinSet}
                onChange={(e) =>
                  setLocalRules({ ...localRules, legsToWinSet: Math.max(1, Number(e.target.value) || 1) })
                }
                style={{ width: "100%", padding: "8px 10px", borderRadius: 10, border: "1px solid #333", background: "#0f0f10", color: "#eee" }}
              />
            </div>
            <div>
              <div style={{ marginBottom: 4, opacity: 0.8 }}>Sets / match</div>
              <input
                type="number"
                min={1}
                value={localRules.setsToWinMatch}
                onChange={(e) =>
                  setLocalRules({ ...localRules, setsToWinMatch: Math.max(1, Number(e.target.value) || 1) })
                }
                style={{ width: "100%", padding: "8px 10px", borderRadius: 10, border: "1px solid #333", background: "#0f0f10", color: "#eee" }}
              />
            </div>
          </div>

          <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
            <GlassButton onClick={start} leftIcon="dart">
              Lancer la partie
            </GlassButton>
            <GlassButton onClick={onBack} leftIcon="folder">
              Annuler
            </GlassButton>
          </div>
        </div>
      </div>
    </section>
  );
}

/* =========================================
   GamePage (minimal avec journal pushEvent)
   ========================================= */
   function GamePage({
    mode,
    rules,
    players,
    setPlayers,
    activeId,
    setActiveId,
    onEnd,
  }: {
    mode: Mode;
    rules: MatchRules;
    players: Player[];
    setPlayers: (u: any) => void;
    activeId: string;
    setActiveId: (id: string) => void;
    onEnd: () => void;
  }) {
    // Helpers
    const idx = (id: string) => players.findIndex((p) => p.id === id);
    const nextId = (id: string) => players[(idx(id) + 1) % Math.max(players.length, 1)]?.id || id;
    const active = players.find((p) => p.id === activeId) || players[0];
  
    // Moyenne X01 (protégée)
    function avg3Darts(start: number, p: Player) {
      const darts = Math.max(1, p.dartsUsed || 0);
      return (((start - (p.x01Score ?? start)) / darts) * 3).toFixed(2);
    }
  
    // Checkout X01 (utilise un mapping global CHECKOUTS si dispo)
    const checkout = React.useMemo(() => {
      if (!active || mode !== "X01") return "";
      const s = active.x01Score;
      const map = (globalThis as any).CHECKOUTS as Record<number, string> | undefined;
      if (s > 170) return "Pas de checkout";
      if (map && map[s]) return map[s];
      return "—";
    }, [active, mode]);
  
    // Applique la volée en X01
    function applyX01(darts: { mult: 1 | 2 | 3; val: number }[]) {
      if (!active) return;
      const total = darts.reduce((sum, d) => {
        if (d.val === 25) return sum + (d.mult === 2 ? 50 : 25);
        return sum + d.val * d.mult;
      }, 0);
  
      const next = active.x01Score - total;
      const last = darts[2] || darts[1] || darts[0];
  
      let bust = false;
      if (next < 0) bust = true;
      if (rules.doubleOut && next === 1) bust = true;
      if (rules.doubleOut && next === 0) {
        const okDouble = last && (last.mult === 2 || (last.val === 25 && last.mult === 2));
        if (!okDouble) bust = true;
      }
  
      if (next === 0 && !bust) {
        // win leg : reset score de tout le monde, +1 leg pour le gagnant
        setPlayers((ps: Player[]) =>
          ps.map((p) =>
            p.id === active.id
              ? { ...p, x01Score: rules.startingScore, legs: p.legs + 1, dartsUsed: p.dartsUsed + 3, lastScore: total }
              : { ...p, x01Score: rules.startingScore }
          )
        );
      } else {
        setPlayers((ps: Player[]) =>
          ps.map((p) =>
            p.id === active.id
              ? {
                  ...p,
                  x01Score: bust ? p.x01Score : next,
                  dartsUsed: p.dartsUsed + 3,
                  lastScore: bust ? 0 : total,
                }
              : p
          )
        );
      }
  
      setActiveId(nextId(active.id));
    }
  
    // Modes non-X01 : on additionne simplement les points de la volée
    function applyGeneric(darts: { mult: 1 | 2 | 3; val: number }[]) {
      if (!active) return;
      const t = darts.reduce((s, d) => s + (d.val === 25 ? (d.mult === 2 ? 50 : 25) : d.val * d.mult), 0);
      setPlayers((ps: Player[]) => ps.map((p) => (p.id === active.id ? { ...p, points: p.points + t, dartsUsed: p.dartsUsed + 3, lastScore: t } : p)));
      setActiveId(nextId(active.id));
    }
  
    function submitTurn(darts: { mult: 1 | 2 | 3; val: number }[]) {
      if (mode === "X01") return applyX01(darts);
      return applyGeneric(darts); // autres modes utilisant la même planche
    }
  
    if (!active) {
      return (
        <section style={{ display: "grid", gap: 12 }}>
          <div style={{ opacity: 0.7 }}>Aucun joueur.</div>
          <button onClick={onEnd} style={{ background: "#111", color: "#fff", border: "1px solid #333", padding: "8px 12px", borderRadius: 12 }}>
            ← Quitter
          </button>
        </section>
      );
    }
  
    return (
      <section style={{ display: "grid", gap: 12 }}>
        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, justifyContent: "space-between" }}>
          <button
            onClick={onEnd}
            style={{ background: "#111", color: "#fff", border: "1px solid #333", borderRadius: 12, padding: "8px 12px" }}
          >
            ← Quitter
          </button>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ opacity: 0.8 }}>
              Mode : <b>{mode}</b>
            </div>
            {/* Bouton infos/règles si tu as un composant InfoButton */}
            {/* <InfoButton mode={mode} /> */}
          </div>
        </div>
  
        {/* Liste joueurs */}
        <div style={{ display: "grid", gap: 8 }}>
          {players.map((p) => (
            <div
              key={p.id}
              onClick={() => setActiveId(p.id)}
              style={{
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: 10,
                borderRadius: 12,
                background: p.id === activeId ? "#191919" : "#121212",
                border: "1px solid #2a2a2a",
              }}
            >
              {/* Gauche : avatar + nom */}
              <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                {/* Passe size={44} pour agrandir les médaillons */}
                <Avatar name={p.name} src={(p as any).avatarDataUrl} size={70} />
                <span style={{ fontWeight: 700 }}>{p.name}</span>
              </span>
  
              {/* Droite : métriques */}
              <span style={{ fontFamily: "monospace", display: "flex", gap: 14, alignItems: "center" }}>
                {mode === "X01" ? (
                  <>
                    <span>
                      Score <b>{p.x01Score}</b>
                    </span>
                    <span>
                      Legs <b>{p.legs}</b>
                    </span>
                    <span>
                      Moy 3D <b>{avg3Darts(rules?.startingScore ?? 501, p)}</b>
                    </span>
                  </>
                ) : (
                  <>
                    <span>
                      Points <b>{p.points}</b>
                    </span>
                    <span>
                      Darts <b>{p.dartsUsed}</b>
                    </span>
                  </>
                )}
              </span>
            </div>
          ))}
        </div>
  
        {/* Pavé + checkout */}
        <div style={{ border: "1px solid #2a2a2a", background: "#0f0f0f", borderRadius: 16, padding: 12 }}>
          <div style={{ marginBottom: 8, display: "flex", alignItems: "center", gap: 10 }}>
            <Avatar name={active?.name || ""} src={(active as any).avatarDataUrl} size={44} />
            <div style={{ fontWeight: 700 }}>{active?.name}</div>
            {mode === "X01" && (
              <div style={{ marginLeft: "auto", fontSize: 12, opacity: 0.8 }}>
                Checkout : <b>{checkout}</b>
              </div>
            )}
          </div>
          <X01Keypad onSubmit={submitTurn} />
        </div>
      </section>
    );
  }

/* =========================================
   AllGamesPage (minimal)
   ========================================= */
function AllGamesPage({
  games,
  events,
  profiles,
  onOpen,
}: {
  games: GameRecord[];
  events: GameEvent[];
  profiles: Profile[];
  onOpen: (id: string) => void;
}) {
  return (
    <section style={{ display: "grid", gap: 10 }}>
      <div style={{ fontWeight: 800 }}>Toutes les parties</div>
      <div style={{ display: "grid", gap: 8 }}>
        {games.length === 0 && <div style={{ opacity: 0.7 }}>Aucune partie enregistrée.</div>}
        {games
          .slice()
          .reverse()
          .map((g) => (
            <button
              key={g.id}
              onClick={() => onOpen(g.id)}
              style={{
                textAlign: "left",
                padding: 10,
                borderRadius: 12,
                border: "1px solid rgba(255,255,255,.08)",
                background: "#0f0f10",
                color: "#e7e7e7",
              }}
            >
              <div style={{ fontWeight: 700 }}>
                {g.mode} • {new Date(g.startedAt).toLocaleString()}
              </div>
              <div style={{ fontSize: 12, opacity: 0.8 }}>
                {g.players.map((p) => profiles.find((x) => x.id === p.profileId)?.name || p.name).join(" vs ")}
              </div>
            </button>
          ))}
      </div>
      <div>
        <GlassButton
          onClick={() => {
            const csv = ["id,mode,startedAt,finishedAt,players"]
              .concat(
                games.map((g) =>
                  [
                    g.id,
                    g.mode,
                    new Date(g.startedAt).toISOString(),
                    g.finishedAt ? new Date(g.finishedAt).toISOString() : "",
                    g.players.map((p) => p.name).join(" | "),
                  ].join(",")
                )
              )
              .join("\n");
            downloadFile("games.csv", csv, "text/csv;charset=utf-8");
          }}
          leftIcon="folder"
        >
          Export CSV parties
        </GlassButton>
      </div>
    </section>
  );
}

/* =========================================
   StatsPage (placeholder)
   ========================================= */
function StatsPage({ profiles }: { profiles: Profile[] }) {
  return (
    <section style={{ display: "grid", gap: 10 }}>
      <div style={{ fontWeight: 700 }}>Stats (placeholder)</div>
      <div style={{ opacity: 0.8 }}>À compléter avec tes graphiques.</div>
    </section>
  );
}

/* =========================================
   TeamsPage (placeholder)
   ========================================= */
function TeamsPage({ teams, setTeams }: { teams: Team[]; setTeams: (u: any) => void }) {
  function addTeam() {
    const t: Team = { id: uid(), name: `Équipe ${teams.length + 1}`, color: "#f59e0b" };
    setTeams((ts: Team[]) => [...ts, t]);
  }
  return (
    <section style={{ display: "grid", gap: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <div style={{ fontWeight: 700 }}>Équipes</div>
        <GlassButton onClick={addTeam} leftIcon="folder">
          + Équipe
        </GlassButton>
      </div>
      <div style={{ display: "grid", gap: 6 }}>
        {teams.map((t) => (
          <div
            key={t.id}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              padding: 8,
              borderRadius: 10,
              border: "1px solid rgba(255,255,255,.08)",
              background: "#0f0f10",
            }}
          >
            <div style={{ height: 18, width: 18, borderRadius: 6, background: t.color, border: "1px solid #333" }} />
            <div style={{ fontWeight: 600 }}>{t.name}</div>
            <div style={{ marginLeft: "auto", opacity: 0.75, fontSize: 12 }}>{t.id}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* =========================================
   SettingsPage (placeholder)
   ========================================= */
function SettingsPage({
  rules,
  setRules,
  arcade,
  setArcade,
}: {
  rules: MatchRules;
  setRules: (r: MatchRules) => void;
  arcade: boolean;
  setArcade: (b: boolean) => void;
}) {
  return (
    <section style={{ display: "grid", gap: 12 }}>
      <div style={{ fontWeight: 700 }}>Réglages</div>
      <div
        style={{
          border: "1px solid rgba(255,255,255,.08)",
          background: "linear-gradient(180deg, rgba(20,20,24,.45), rgba(10,10,12,.55))",
          borderRadius: 12,
          padding: 12,
        }}
      >
        <div style={{ fontWeight: 700, marginBottom: 8 }}>X01</div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 8 }}>
          {[301, 501, 701, 1001].map((s) => (
            <GlassButton key={s} onClick={() => setRules({ ...rules, startingScore: s })} active={rules.startingScore === s}>
              {s}
            </GlassButton>
          ))}
        </div>
        <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <input type="checkbox" checked={rules.doubleOut} onChange={(e) => setRules({ ...rules, doubleOut: e.target.checked })} />
          Sortie en double
        </label>
      </div>

      <div
        style={{
          border: "1px solid rgba(255,255,255,.08)",
          background: "linear-gradient(180deg, rgba(20,20,24,.45), rgba(10,10,12,.55))",
          borderRadius: 12,
          padding: 12,
        }}
      >
        <div style={{ fontWeight: 700, marginBottom: 8 }}>Ambiance</div>
        <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <input type="checkbox" checked={arcade} onChange={(e) => setArcade(e.target.checked)} />
          Mode arcade (fond néon)
        </label>
      </div>
    </section>
  );
}

/* ========= X01Keypad (3 fléchettes, auto-avance, retour ←) ========= */

function X01Keypad({
  onSubmit,
  onCancel,
  label = "Valider la volée",
}: {
  onSubmit: (darts: Dart[]) => void;
  onCancel?: () => void;
  label?: string;
}) {
  const [darts, setDarts] = React.useState<Array<Dart | null>>([null, null, null]);
  const [active, setActive] = React.useState<number>(0);          // 0..2
  const [multNext, setMultNext] = React.useState<1 | 2 | 3>(1);   // S par défaut

  const total = React.useMemo(() => {
    const filled = darts.map((d) => d ?? { mult: 1, val: 0 });
    return filled.reduce((s, d) => (d.val === 25 ? s + (d.mult === 2 ? 50 : 25) : s + d.val * d.mult), 0);
  }, [darts]);

  function putNumber(n: number) {
    // place la fléchette courante…
    const current = { mult: multNext, val: n } as Dart;
    setDarts((ds) => {
      const copy = [...ds];
      copy[active] = current;
      return copy;
    });
    setMultNext(1); // redevient Simple pour la prochaine

    // passe à la suivante OU soumet si c'était la 3e
    setActive((i) => {
      if (i === 2) {
        const payload = [darts[0] ?? { mult: 1, val: 0 }, darts[1] ?? { mult: 1, val: 0 }, current] as Dart[];
        onSubmit(payload);
        // reset pour le tour suivant
        setTimeout(() => {
          setDarts([null, null, null]);
          setActive(0);
          setMultNext(1);
        }, 0);
        return 2;
      }
      return i + 1;
    });
  }

  function backspace() {
    const last = [2, 1, 0].find((i) => darts[i] !== null) ?? 0;
    setDarts((ds) => {
      const copy = [...ds];
      copy[last] = null;
      return copy;
    });
    setActive(last);
  }

  function submitManuel() {
    const payload = darts.map((d) => d ?? ({ mult: 1, val: 0 } as Dart)) as Dart[];
    onSubmit(payload);
    setDarts([null, null, null]);
    setActive(0);
    setMultNext(1);
  }

  const numBtn = (txt: string, onClick: () => void) => ({
    children: txt,
    onClick,
    style: {
      padding: "10px 0",
      borderRadius: 10,
      border: "1px solid #333",
      background: "#151515",
      color: "#ddd",
      cursor: "pointer",
    } as React.CSSProperties,
  });

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {/* Indicateur flèche active */}
      <div style={{ display: "flex", gap: 8 }}>
        {[0, 1, 2].map((i) => (
          <button
            key={i}
            onClick={() => setActive(i)}
            style={{
              flex: 1,
              padding: "8px 0",
              borderRadius: 10,
              border: "1px solid #333",
              background: active === i ? "#fbbf24" : "#111",
              color: active === i ? "#111" : "#ddd",
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            Flèche {i + 1} {darts[i] ? "• ✓" : ""}
          </button>
        ))}
      </div>

      {/* D / T / ← retour (plus de bouton Simple) */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8 }}>
        <button onClick={() => setMultNext(2)} style={{ padding: "10px 0", borderRadius: 10, border: "1px solid #1f3a45", background: multNext===2?"#0c2530":"#102228", color:"#aee3ff", fontWeight:700, cursor:"pointer" }}>DOUBLE</button>
        <button onClick={() => setMultNext(3)} style={{ padding: "10px 0", borderRadius: 10, border: "1px solid #3a1f45", background: multNext===3?"#2a0c30":"#281022", color:"#ffb3e1", fontWeight:700, cursor:"pointer" }}>TRIPLE</button>
        <button onClick={backspace} title="Retour" style={{ padding: "10px 0", borderRadius: 10, border: "1px solid #333", background:"#151515", color:"#ddd", fontWeight:700, cursor:"pointer" }}>←</button>
      </div>

      {/* Pavé 0..20 + 25 */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 6 }}>
        <button {...numBtn("0", () => putNumber(0))} />
        {[...Array(21)].map((_, i) => (
          <button key={i + 1} {...numBtn(String(i + 1), () => putNumber(i + 1))} />
        ))}
        <button {...numBtn("25", () => putNumber(25))} />
      </div>

      {/* Actions / Total */}
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ fontFamily: "monospace" }}>
          Total volée : <b>{total}</b> &nbsp;|&nbsp; Prochain multiplicateur : <b>{multNext === 1 ? "S" : multNext === 2 ? "D" : "T"}</b>
        </div>
        <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
          {onCancel && <button onClick={onCancel} style={{ background:"#111", color:"#fff", border:"1px solid #333", padding:"10px 14px", borderRadius:10, cursor:"pointer" }}>Annuler</button>}
          <button onClick={submitManuel} style={{ background:"#fbbf24", color:"#111", border:"none", padding:"10px 14px", borderRadius:10, fontWeight:700, cursor:"pointer" }}>{label}</button>
          <button
  onClick={() => setRoute("gamestats")}
  style={{
    background: "#222",
    color: "#fbbf24",
    border: "1px solid #333",
    borderRadius: 10,
    padding: "8px 12px",
    fontWeight: 700,
  }}
>
  📈 Voir les stats de la partie
</button>
        </div>
      </div>
    </div>
  );
}

const padBtnStyle: React.CSSProperties = {
  padding: "10px 0",
  borderRadius: 10,
  border: "1px solid rgba(255,255,255,.08)",
  background: "#151515",
  color: "#ddd",
};

const numBtnStyle: React.CSSProperties = {
  padding: "10px 0",
  borderRadius: 10,
  border: "1px solid rgba(255,255,255,.08)",
  background: "#151515",
  color: "#ddd",
};

/* =========================================
   Avatar
   ========================================= */
function Avatar({ name, src, size = 70 }: { name: string; src?: string; size?: number }) {
  const initials = (name || "?")
    .split(" ")
    .map((x) => x[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
  return src ? (
    <img
      src={src}
      alt={name}
      style={{ width: size, height: size, borderRadius: 999, objectFit: "cover", border: "1px solid #333" }}
    />
  ) : (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: 999,
        background: "linear-gradient(180deg, #1a1a1d, #0e0e11)",
        border: "1px solid #333",
        display: "grid",
        placeItems: "center",
        fontSize: size < 28 ? 11 : 12,
        fontWeight: 800,
      }}
    >
      {initials}
    </div>
  );
}

/* =========================================
   Glass UI helpers
   ========================================= */
function GlassButton({
  children,
  onClick,
  active,
  leftIcon,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  active?: boolean;
  leftIcon?: IconName;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        appearance: "none",
        border: active ? "1px solid rgba(245,158,11,.35)" : "1px solid rgba(255,255,255,.08)",
        background: active
          ? "radial-gradient(120px 60px at 50% -20%, rgba(245,158,11,.28), rgba(245,158,11,.07))"
          : "linear-gradient(180deg, rgba(20,20,24,.45), rgba(10,10,12,.55))",
        color: active ? "var(--c-primary)" : "#e7e7e7",
        padding: "10px 14px",
        borderRadius: 14,
        display: "inline-flex",
        alignItems: "center",
        gap: 8,
        cursor: "pointer",
        backdropFilter: "blur(6px)",
        WebkitBackdropFilter: "blur(6px)",
        transition: "all 160ms ease",
        fontWeight: active ? 800 : 700,
      }}
    >
      {leftIcon && <Icon name={leftIcon} active={active} />}
      {children}
    </button>
  );
}

/* =========================================
   Top & Bottom nav (verre dépoli + SVG)
   ========================================= */
type IconName = "home" | "dart" | "user" | "folder" | "chart" | "settings";

function TopGlassNav({ route, setRoute }: { route: Route; setRoute: (r: Route) => void }) {
  return (
    <nav
      className="hide-sm"
      style={{
        position: "sticky",
        top: 0,
        zIndex: 60,
        display: "flex",
        gap: 8,
        alignItems: "center",
        justifyContent: "center",
        padding: "10px 12px",
        borderBottom: "1px solid rgba(255,255,255,.07)",
        background: "linear-gradient(180deg, rgba(18,18,22,.55), rgba(10,10,12,.72))",
        backdropFilter: "blur(10px)",
        WebkitBackdropFilter: "blur(10px)",
      }}
    >
      <NavButtons route={route} setRoute={setRoute} layout="row" />
    </nav>
  );
}

function BottomNav({ route, setRoute }: { route: Route; setRoute: (r: Route) => void }) {
  return (
    <nav
      className="show-sm"
      style={{
        position: "fixed",
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 50,
        display: "grid",
        gridTemplateColumns: "repeat(6,1fr)",
        alignItems: "center",
        gap: 6,
        padding: "10px 12px",
        borderTop: "1px solid rgba(255,255,255,.07)",
        background: "linear-gradient(180deg, rgba(18,18,22,.55), rgba(10,10,12,.72))",
        backdropFilter: "blur(10px)",
        WebkitBackdropFilter: "blur(10px)",
      }}
    >
      <NavButtons route={route} setRoute={setRoute} layout="grid" />
    </nav>
  );
}

function NavButtons({ route, setRoute, layout }: { route: Route; setRoute: (r: Route) => void; layout: "row" | "grid" }) {
  const items: { key: Route; label: string; icon: IconName }[] = [
    { key: "home", label: "Accueil", icon: "home" },
    { key: "games", label: "Jeux", icon: "dart" },
    { key: "profiles", label: "Profils", icon: "user" },
    { key: "allgames", label: "Tous les jeux", icon: "folder" },
    { key: "stats", label: "Stats", icon: "chart" },
    { key: "settings", label: "Réglages", icon: "settings" },
  ];
  const btnBase: React.CSSProperties = {
    appearance: "none",
    border: "1px solid transparent",
    background: "transparent",
    color: "#e7e7e7",
    padding: layout === "row" ? "8px 10px" : "8px 4px",
    borderRadius: 12,
    display: "flex",
    flexDirection: layout === "row" ? "row" : "column",
    alignItems: "center",
    gap: 6,
    cursor: "pointer",
    transition: "transform 120ms ease, background 160ms ease, color 160ms ease, border 160ms ease",
    fontSize: 12,
    lineHeight: 1.1,
  };
  const activeBg = "radial-gradient(120px 60px at 50% -20%, rgba(245,158,11,.35), rgba(245,158,11,.08))";

  return (
    <>
      {items.map((it) => {
        const active = route === it.key;
        return (
          <button
            key={it.key}
            onClick={() => setRoute(it.key)}
            aria-current={active ? "page" : undefined}
            title={it.label}
            style={{
              ...btnBase,
              background: active ? activeBg : "transparent",
              color: active ? "var(--c-primary)" : "#e7e7e7",
              border: active ? "1px solid rgba(245,158,11,.35)" : "1px solid transparent",
              fontWeight: active ? 800 : 600,
            }}
          >
            <Icon name={it.icon} active={active} />
            <span style={{ whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden", maxWidth: 120 }}>
              {it.label}
            </span>
          </button>
        );
      })}
    </>
  );
}

function Icon({ name, active }: { name: IconName; active?: boolean }) {
  const stroke = active ? "var(--c-primary)" : "#e7e7e7";
  const dim = 22;
  const common = {
    width: dim,
    height: dim,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke,
    strokeWidth: 1.75,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  switch (name) {
    case "home":
      return (
        <svg {...common}>
          <path d="M3 10.5 12 3l9 7.5" />
          <path d="M5 10.5V21h14V10.5" />
          <path d="M9 21v-6h6v6" />
        </svg>
      );
    case "dart":
      return (
        <svg {...common}>
          <path d="M3 3l4 1 4 4-2 2-4-4-1-4z" />
          <path d="M11 8l9 9" />
          <path d="M14 14l-3 6 6-3" />
        </svg>
      );
    case "user":
      return (
        <svg {...common}>
          <path d="M12 12a4.5 4.5 0 1 0-0.001-9.001A4.5 4.5 0 0 0 12 12z" />
          <path d="M4 21c0-4.418 3.582-7 8-7s8 2.582 8 7" />
        </svg>
      );
    case "folder":
      return (
        <svg {...common}>
          <path d="M3 7h6l2 2h10v9a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V7z" />
          <path d="M3 7V6a3 3 0 0 1 3-3h3l2 2" />
        </svg>
      );
    case "chart":
      return (
        <svg {...common}>
          <path d="M3 21h18" />
          <rect x="5" y="10" width="3" height="8" rx="1" />
          <rect x="10.5" y="6" width="3" height="12" rx="1" />
          <rect x="16" y="13" width="3" height="5" rx="1" />
        </svg>
      );
    case "settings":
      return (
        <svg {...common}>
          <path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z" />
          <path d="M19.4 15a1.8 1.8 0 0 0 .36 1.98l.02.02a2 2 0 1 1-2.83 2.83l-.02-.02A1.8 1.8 0 0 0 15 19.4a1.8 1.8 0 0 0-3 0 1.8 1.8 0 0 0-1.98.36l-.02.02a2 2 0 1 1-2.83-2.83l.02-.02A1.8 1.8 0 0 0 4.6 15a1.8 1.8 0 0 0 0-3 1.8 1.8 0 0 0-.36-1.98l-.02-.02a2 2 0 1 1 2.83-2.83l.02.02A1.8 1.8 0 0 0 9 4.6a1.8 1.8 0 0 0 3 0 1.8 1.8 0 0 0 1.98-.36l.02-.02a2 2 0 1 1 2.83 2.83l-.02.02A1.8 1.8 0 0 0 19.4 12c0 .35.12.69.36 1z" />
        </svg>
      );
  }
}

/* =========================================
   SectionTabs (verre dépoli, réutilisable)
   ========================================= */
type TabItem = { key: string; label: string; icon?: IconName };
function SectionTabs({
  tabs,
  value,
  onChange,
  rightSlot,
}: {
  tabs: TabItem[];
  value: string;
  onChange: (k: string) => void;
  rightSlot?: React.ReactNode;
}) {
  const bar: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
    gap: 6,
    padding: 6,
    borderRadius: 14,
    background: "linear-gradient(180deg, rgba(20,20,24,.45), rgba(10,10,12,.55))",
    border: "1px solid rgba(255,255,255,.07)",
    backdropFilter: "blur(6px)",
  };
  const btn: React.CSSProperties = {
    appearance: "none",
    border: "1px solid transparent",
    background: "transparent",
    color: "#e7e7e7",
    padding: "8px 10px",
    borderRadius: 12,
    display: "flex",
    alignItems: "center",
    gap: 8,
    cursor: "pointer",
    fontSize: 13,
    transition: "all 160ms ease",
  };
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
      <div style={bar}>
        {tabs.map((t) => {
          const active = t.key === value;
          return (
            <button
              key={t.key}
              onClick={() => onChange(t.key)}
              style={{
                ...btn,
                background: active
                  ? "radial-gradient(100px 50px at 50% -20%, rgba(245,158,11,.28), rgba(245,158,11,.07))"
                  : "transparent",
                color: active ? "var(--c-primary)" : "#e7e7e7",
                border: active ? "1px solid rgba(245,158,11,.35)" : "1px solid transparent",
                fontWeight: active ? 800 : 600,
              }}
            >
              {t.icon && <Icon name={t.icon} active={active} />}
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>
      {rightSlot}
    </div>
  );
}
/* ===================== Modal (verre dépoli) ===================== */
function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}) {
  if (!open) return null;
  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,.5)",
        display: "grid",
        placeItems: "center",
        zIndex: 100,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "min(720px, 92vw)",
          maxHeight: "80vh",
          overflow: "auto",
          borderRadius: 16,
          border: "1px solid rgba(255,255,255,.08)",
          background:
            "linear-gradient(180deg, rgba(20,20,24,.65), rgba(10,10,12,.85))",
          padding: 16,
          color: "#eee",
          backdropFilter: "blur(10px)",
          WebkitBackdropFilter: "blur(10px)",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ fontWeight: 800, fontSize: 18 }}>{title}</div>
          <button
            onClick={onClose}
            style={{
              marginLeft: "auto",
              border: "1px solid rgba(255,255,255,.08)",
              background: "#0e0e11",
              color: "#eee",
              padding: "6px 10px",
              borderRadius: 10,
              cursor: "pointer",
            }}
          >
            Fermer
          </button>
        </div>
        <div style={{ marginTop: 10, lineHeight: 1.5 }}>{children}</div>
      </div>
    </div>
  );
}
function InfoButton({ mode }: { mode: string }) {
  const [open, setOpen] = React.useState(false);
  const key = MODE_TO_RULE_KEY[mode] || mode;
  const text = GAME_RULES[key];

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        title="Règles"
        style={{
          border: "1px solid rgba(255,255,255,.08)",
          background: "linear-gradient(180deg, rgba(20,20,24,.45), rgba(10,10,12,.55))",
          color: "#e7e7e7",
          padding: "8px 10px",
          borderRadius: 12,
          cursor: "pointer",
          fontWeight: 700,
        }}
      >
        i
      </button>

      <Modal open={open} onClose={() => setOpen(false)} title={`Règles — ${mode}`}>
        {text ? (
          <pre style={{ whiteSpace: "pre-wrap", fontFamily: "inherit", margin: 0 }}>{text}</pre>
        ) : (
          <div>Règles à venir.</div>
        )}
      </Modal>
    </>
  );
}
